using System;

class Another
{
    public void Add<T>(T a,T b)
    {
        dynamic d1=a;
        dynamic d2=b;
        Console.WriteLine(d1+d2);
    }

    public void sub<T>(T a,T b)
    {
        dynamic d1=a;
        dynamic d2=b;
        Console.WriteLine(d1-d2);
    }
    public void mul<T>(T a ,T b)
    {
        dynamic d1=a;
        dynamic d2=b;
        Console.WriteLine(d1*d2);
    }
    public void div<T>(T a ,T b)
    {
        dynamic d1=a;
        dynamic d2=b;
        Console.WriteLine(d1/d2);
    }
}