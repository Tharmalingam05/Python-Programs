﻿using Internal;
using System;
class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Another Method for Delegate---");
        Console.WriteLine();

        Func<int,float,double,double>obj1=Deleg.Addnums1;
        double result=obj1(12,89.5f,90);
        Console.WriteLine(result);

        Action<int,float,double> obj2=Deleg.Addnums2;
        obj2(12,34.5f,45);

        Predicate<string> obj3=Deleg.checkLength;
        bool res=obj3("Santhosh");
        Console.WriteLine(res);

        // Func<string,bool> obj3=Deleg.checkLength;
        // bool res=obj3("Santhosh");
        // Console.WriteLine(res);
    }
}